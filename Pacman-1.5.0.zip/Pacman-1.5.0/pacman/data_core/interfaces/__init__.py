from .idrawable import IDrawable
from .ieventful import IEventful
from .ilogical import ILogical
