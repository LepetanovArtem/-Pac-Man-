from .blinky import Blinky
from .clyde import Clyde
from .inky import Inky
from .pinky import Pinky
